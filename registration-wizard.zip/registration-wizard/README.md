# Registration Wizard — Sprint 07

A responsive, three-step registration form built with React, Vite, React Hook Form, and Zod.

## Features

- Three conditional steps: Personal Information, Account Details, and Review & Submit.
- Parent-level form state so entered information remains when navigating Back and Next.
- Live validation with readable error messages.
- Email format validation, password minimum length of 8, and matching confirmation.
- Show/hide password controls.
- Disabled Next buttons until the current step is valid.
- Progress indicator.
- Review screen and success confirmation.
- `Prompts.md` for documenting AI-assisted debugging and learning.
- Vercel rewrite configuration for SPA deployment.

## Requirements

Install Node.js LTS from https://nodejs.org/ and Git from https://git-scm.com/install/windows if they are not already installed.

## Run in VS Code

1. Extract this ZIP file.
2. In VS Code, choose **File → Open Folder** and open the extracted `registration-wizard` folder.
3. Open **Terminal → New Terminal**.
4. Run:

   ```bash
   npm install
   npm run dev
   ```

5. Open the local URL printed in the terminal, usually `http://localhost:5173/`.

Use `Ctrl+C` in the terminal to stop the server.

## Verify before submitting

```bash
npm run build
```

A successful build creates the `dist` folder.

## GitHub upload

Create an empty GitHub repository first. In the VS Code terminal, from this project folder run:

```bash
git init
git add .
git commit -m "Build registration wizard"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the URL with the actual URL of your own repository. If Git says `remote origin already exists`, use `git remote set-url origin YOUR-REPOSITORY-URL` instead of `git remote add origin ...`.

## Deploy to Vercel

1. Push the project to GitHub.
2. Sign in at https://vercel.com/ and import the repository.
3. Keep the default Vite settings: Build Command `npm run build`, Output Directory `dist`.
4. Deploy and open the live URL.

## Important privacy note

This is a front-end learning project. It does not create a real account or send data to a backend. Never enter a real password. The submitted payload is logged to the browser console to meet the sprint's client-side demonstration requirement. The review screen intentionally does not display the password.

## Understand the code

- `src/App.jsx`: owns the active step and unified form state, so child steps can unmount without losing data.
- `src/schemas/registrationSchema.js`: Zod rules for the whole registration form.
- `src/components/StepOne.jsx`: personal details and live validation.
- `src/components/StepTwo.jsx`: email/password validation and password visibility toggles.
- `src/components/StepThree.jsx`: review and submit.
- `src/components/ProgressBar.jsx`: step number and progress.
- `src/main.jsx`: React entry point.
- `src/index.css`: layout and responsive styles.
